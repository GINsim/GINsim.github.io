srv_reverser = lqm.srv.getModifier("reverse")
srv_booleanizer  = lqm.srv.getModifier("booleanize")

for (a in lqm.args) {
    name = lqm.args[a]
    model = lqm.loadModel(name+".sbml")
    
    boolmodel = srv_booleanizer.getModifiedModel(model)
    revmodel = srv_reverser.getModifiedModel(model)
    
    lqm.saveModel(boolmodel, name+"_bool.sbml", "sbml")
    lqm.saveModel(revmodel, name+"_bool_reversed.sbml", "sbml")
}

