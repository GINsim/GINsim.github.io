from __future__ import print_function

import re
import os
import sys
from sys import platform
from subprocess import call

# Read all lines from a .txt file
def get_f_lines(f_file):
    fh = open(f_file, 'r')
    lines = fh.readlines()
    fh.close()
    return lines

# Parse lines from a boolsim file into an internal matrix
def is_boolsim(f_lines):
    n = len(f_lines[0].rstrip().split(' '))
    for line in f_lines[1:]:
        values = line.rstrip().split(' ')
        if len(values) != n:
            print('values != n')
            return False
        for v in values:
            if v not in ('0', '1', '2'):
                print(v,'not in 0,1,2')
                return False
    return True
def parse_boolsim(f_lines):
    nodes = f_lines[0].rstrip().split(' ')
    matrix = []
    for line in f_lines[1:]:
        matrix += [line.rstrip().split(' ')]
    return (matrix, nodes)

# Parse lines from an espresso file into an internal matrix
def is_espresso(f_lines):
    return len(f_lines) > 4 and f_lines[0].startswith('.i') and \
            f_lines[1].startswith('.o') and f_lines[2].startswith('.p')
def parse_espresso(f_lines):
    matrix = []
    for l in range(3,len(f_lines)-1):
        lvals = []
        for i in range(len(f_lines[l])-3):
            lvals = lvals + [f_lines[l][i]]
        matrix = matrix + [lvals]
    return matrix

# Writes a matrix to an espresso specification file
def matrix_2_f_espresso(matrix, f_espresso):
    # Write to tmp file
    fh = open(f_espresso, 'w')
    fh.write(".i " + str(len(matrix[0])) + "\n.o 1\n")
    # No need to transpose matrix, due to boolSim new --transpose option 
    for line in matrix:
        tmp = ""
        for v in line:
            if v == "2":
                tmp += "-" # This is a * in espresso
            else:
                tmp += v
        fh.write(tmp+" 1\n");
    fh.write(".e")
    fh.close()

# Writes a matrix to a TSV file to be read by the user
def matrix_2_f_user(matrix, f_pattern, nodes = None):
    # Write to pattern file
    fh = open(f_pattern, 'w')
    txt = ""
    if nodes:
        txt = ' '.join(nodes) + "\n"
    for i in range(len(matrix)):
        line = ""
        for j in range(len(matrix[0])):
            if j > 0:
                line += "\t"
            if matrix[i][j] == "-" or matrix[i][j] == "2":
                line += "*"
            else:
                line += matrix[i][j]
        txt += line + "\n"
    fh.write(txt)
    fh.close()

# Delete temporary file
def f_delete(f_file):
    if os.path.exists(f_file):
        os.remove(f_file)

if platform == "darwin":
    ESPRESSO=os.path.dirname(os.path.abspath(sys.argv[0]))+"/tools/espresso/MacOSX/espresso-64bit"
else:
    ESPRESSO=os.path.dirname(os.path.abspath(sys.argv[0]))+"/tools/espresso/Linux/espresso-64bit"
if os.path.exists(ESPRESSO):
    has_espresso = True
else:
    has_espresso = False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print( "Usage: %s <some_file_1.txt> ... <some_file_n.txt>" % sys.argv[0] )
        sys.exit()

    if not has_espresso:
        print( "Warning: " + ESPRESSO + " binary is not available" )
        print( "Warning: resulting pattern may not be minimal !" )

    f_tmp = 'tmp_espresso.txt'
    for f_input in sys.argv[1:]:
        if not f_input.endswith('.txt'):
            print( f_input + " must have a .txt extension")
            continue

        f_user = f_input[:-4] + "_pattern.txt"
        print("In: " + f_input)
        f_lines = get_f_lines(f_input)
        if is_boolsim(f_lines):
            print("\tis_boolsim")
            matrix, nodes = parse_boolsim(f_lines)
            if has_espresso:
                print("\thas_espresso")
                matrix_2_f_espresso(matrix, f_tmp)
                f_pattern = f_tmp[:-4] + "_pattern.txt"
                with open(f_pattern, 'w') as fh:
                    call( [ ESPRESSO, f_tmp ], stdout=fh )
                matrix = parse_espresso(get_f_lines(f_pattern))
                f_delete(f_tmp)
                f_delete(f_pattern)
            matrix_2_f_user(matrix, f_user, nodes)
            print("\tPattern: " + f_user)
        elif is_espresso(f_lines):
            print("\tis_espresso")
            matrix = parse_espresso(f_lines)
            matrix_2_f_user(matrix, f_user)
            print("\tPattern: " + f_user)
        else:
            print( f_input + " file has an invalid format")

