from __future__ import print_function

import os
import sys
from sys import platform
from subprocess import call

installpath=os.path.dirname(os.path.abspath(sys.argv[0]))+"/"
BioLQMfolder=installpath+"tools/bioLQM/"
BioLQM=BioLQMfolder+"bioLQM-0.4-SNAPSHOT-jar-with-dependencies.jar"

if platform == "darwin":
    BOOLSIMFOLDER=installpath+"tools/boolSim/MacOSX"
else:
    BOOLSIMFOLDER=installpath+"tools/boolSim/Linux"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print( "Usage: %s <model.sbml>" % sys.argv[0] ,file=sys.stderr)
        sys.exit()
    
    for f in sys.argv[1:]:
        if f.endswith('.sbml'): f = f[:-5]
        if os.path.exists(BioLQM):
            command=('java', '-jar', BioLQM, '-s', BioLQMfolder+'/reverse.js', f)
            print("#Generate Boolean model and reverse Boolean model: ")
            print(" ".join(command))
            print("")
            call(command)
        
        f += "_bool"
        model = "%s.sbml" % f
        revmodel = "%s_reversed.sbml" % f
        attractors = '%s_attractor' % f
        weak = '%s_weak_basin' % f
        strong = '%s_strong_basin' % f
        externalboundary = '%s_strong_basin_external_boundary' % f
        internalboundary = '%s_strong_basin_internal_boundary' % f
        
        command = (BOOLSIMFOLDER+"/boolSim", '-t', '-f', model, '-p', '3', '-o', attractors)
        print("#Attractors: ")
        print(" ".join(command))
        print("")
        call( command  )

        i = 1
        while True:
            f_ini = '%s_%s.txt'%(attractors,i)
            if not os.path.exists(f_ini): break
            f_rch = '%s_%s.txt'%(weak,i)
            command = (BOOLSIMFOLDER+"/boolSim", '-t', '-f', revmodel, '-p', '3', '-i', f_ini, '-o', f_rch)
            print("#Weak basin of attraction %s: states reached by reverse model starting from attractor %s of the original model."%(i,i))
            print(" ".join(command))
            print("")
            call( command  )
            i += 1

        print("found %s attractors" % (i-1),file=sys.stderr)

        if i < 2:
            print('without multiple attractors, no need to continue',file=sys.stderr)
            continue
        
        print('lookup strong bassins',file=sys.stderr)
        for k in range(1,i):
            f_ini = '%s_%s.txt'%(weak,k)
            command = [BOOLSIMFOLDER+"/boolSim_setutils", '-t', 'difference', f_ini, ]
            command += [ '%s_%s.txt'%(weak,j) for j in range(1,i) if j != k ]
            command += [ '-o', '%s_%s.txt'%(strong,k) ]
            
            
            print("#Strong basin of attraction %s: difference between weak basin of attraction %i and all other weak basins of attraction"%(k,k))
            print(" ".join(command))
            print("")
            call( command )

        print('lookup strong bassins external boundaries',file=sys.stderr)
        for k in range(1,i):
            f_ini = '%s_%s.txt'%(strong,k)
            f_bdry = '%s_%s.txt'%(externalboundary,k)
            command = (BOOLSIMFOLDER+"/boolSim", '-t', '-n','1','-f', revmodel, '-p', '3', '-i', f_ini, '-o', f_bdry)
            print("#Strong basin of attraction %s external boundary: evaluate states reached in one step by reverse model, starting from strong basin of attraction %s of the original model."%(k,k))
            print(" ".join(command))
            call( command  )

            f_ini = '%s_%s.txt'%(strong,k)
            f_bdry = '%s_%s.txt'%(externalboundary,k)
            command = (BOOLSIMFOLDER+"/boolSim_setutils", '-t', 'difference',f_bdry,f_ini,'-o',f_bdry )
            print("#Strong basin of attraction %s external boundary: remove strong basin of attraction from boundary."%(k))
            print(" ".join(command))
            print("")
            call( command  )

        print('lookup strong bassins internal boundaries',file=sys.stderr)
        for k in range(1,i):
            f_ini = '%s_%s.txt'%(externalboundary,k)
            f_bdry = '%s_%s.txt'%(internalboundary,k)
            command = (BOOLSIMFOLDER+"/boolSim", '-t', '-n','1','-f', model, '-p', '3', '-i', f_ini, '-o', f_bdry)
            print("#Strong basin of attraction %s internal boundary: evaluate states reached in one step, starting from external boundary of strong basin of attraction %s."%(k,k))
            print(" ".join(command))
            call( command  )

            f_ini = '%s_%s.txt'%(strong,k)
            f_bdry = '%s_%s.txt'%(internalboundary,k)
            command = (BOOLSIMFOLDER+"/boolSim_setutils", '-t', 'intersection',f_bdry,f_ini,'-o',f_bdry )
            print("#Strong basin of attraction %s external boundary: keep only states in strong basin of attraction."%(k))
            print(" ".join(command))
            print("")
            call( command  )

