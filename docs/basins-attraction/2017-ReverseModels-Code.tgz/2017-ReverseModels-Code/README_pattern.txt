# Given a boolsim output file, containing a set of states/patterns,
# this script tries to obtain a minimal set of patterns representing
# the same set of states/patterns.

# For this it used the ESPRESSO heuristic logic minimizer
# Brayton et al. (1984), Logic Minimization Algorithms for VLSI 
# Synthesis, Kluwer Academic Publishers

# The script get_pattern.py receives one or more boolsim/espresso
# output files (which must have a .txt extension). For each one:
# - if is boolsim file:
#   . extracts the set of states/patterns specified as columns
#   . if has espresso:
#     . calls the espresso minimization
#		. writes a tab separated file with the minimized pattern
# - if is an espresso file:
#		. writes a tab separated file with the minimized pattern

# Each input file <some_file.txt> will have a corresponding
# output file <some_file_pattern.txt>


# Usage:
# python get_pattern.py <boolsim_file_1.txt> ... <boolsim_file_n.txt>

# Examples:
python get_pattern.py examples/calzone2010/Calzone_2010_reduced_bool_strong_basin_1.txt  examples/calzone2010/Calzone_2010_reduced_bool_strong_basin_2.txt  examples/calzone2010/Calzone_2010_reduced_bool_strong_basin_3.txt 

In: examples/calzone2010/Calzone_2010_reduced_bool_strong_basin_1.txt
	is_boolsim
	has_espresso
	Pattern: examples/calzone2010/Calzone_2010_reduced_bool_strong_basin_1_pattern.txt
In: examples/calzone2010/Calzone_2010_reduced_bool_strong_basin_2.txt
	is_boolsim
	has_espresso
	Pattern: examples/calzone2010/Calzone_2010_reduced_bool_strong_basin_2_pattern.txt
In: examples/calzone2010/Calzone_2010_reduced_bool_strong_basin_3.txt
	is_boolsim
	has_espresso
	Pattern: examples/calzone2010/Calzone_2010_reduced_bool_strong_basin_3_pattern.txt
