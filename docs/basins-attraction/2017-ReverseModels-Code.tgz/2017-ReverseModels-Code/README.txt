
The python script reverse_study.py calls bioLQM with the reverse.js script to prepare the pair of boolean models (original and reversed models).
Then it calls boolsim to identify attractors using the original model and their backward reachable states using the reversed model (weak basins of attractions).
It then use boolsim_setutils to compute the strong basin of attraction for each attractor.
In the future it will turn the boolean patterns into multivalued ones


To run it:

python reverse_study.py examples/calzone2010/Calzone_2010_reduced.sbml


Requirements:
* bioLQM needs java 1.6
* boolsim was compiled for linux and Mac x64, should hopefully work on most not-so-old versions

