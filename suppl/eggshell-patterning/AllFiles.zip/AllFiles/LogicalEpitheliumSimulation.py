# -*- coding: UTF-8
'''
Created on 2 août 2010

@author: adrien
Edited by OdW, 201103
TODO:
V Refactor line lengths
* Remove Tix5
# Remove HList (replace with Tkinter.listbox)
# Remove Notebook (replace with properly places frames)
* Document
* remove lxml? python has built-in elementree support... => DONE (Adrien)

Edited by adrien, 20120915:
+ updated with all the stuff I independently developped since OdW worked on this programme.
+ removed lxml — seems to work fine, except for the "prettyprint" option, replaced with indent function.

Edited by adrien, 20130201
+ created states menu, load and save
+ updated model file format accordingly
+ replaced selectionframe with OptionMenu button
+ created "model" class distinct from GUI

TODO:
- make buttons inactive when no model is loded (otherwise: error message)
- unselect all cells (now it only works when clicking on the side of the canvas, but that's a bug more than a feature)

'''
import sys
import os
from Tkinter import *
##from Tix import *
import pickle
import tkFileDialog
#from lxml import etree
import xml.etree.ElementTree as etree


def indent(elem, level=0):
    """from: http://infix.se/2007/02/06/gentlemen-indent-your-xml
    """
    i = "\n" + level*"  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        for e in elem:
            indent(e, level+1)
            if not e.tail or not e.tail.strip():
                e.tail = i + "  "
        if not e.tail or not e.tail.strip():
            e.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


def mixcolors(colors=["#000000"]):
    """Blends the colors on the list by averaging their hexadecimal values.
    """
    r=0
    g=0
    b=0
    for color in colors:
        r+=int(color[1:3],16)
        g+=int(color[3:5],16)
        b+=int(color[5:7],16)
    return "#{0:02x}{1:02x}{2:02x}".format(r//len(colors),g//len(colors),b//len(colors))


class GlobalSpecies():
    def __init__(self, name, maxlevel=1, priority=0, rule=["True"], color="#000000"):
        self.name=name
        self.rule=rule
        self.maxlevel=maxlevel
        self.priority= priority
        self.color=color   
         
         
    def setcolor(self,  color):
        self.color = color
    def setmaxlevel(self,  maxlevel):
        self.maxlevel=maxlevel
    def setpriority(self, priority):
        self.priority = priority
        
    def setrule(self, level, rule):
        self.rule[level]=rule

class Species():
    def __init__(self, speciestype, parentcell, value=0, localrule=[]):
        self.speciestype=speciestype #globalspecies
        self.parentcell = parentcell   
        self.value=value
        self.localrule=localrule #meant for mutants... but not used.

    def copy(self):
        """returns a copy of the species"""
        return Species(self.speciestype, self.parentcell, self.value, self.localrule)
    
    def update(self):
        """ updates a species.
        Species whose name begins with "+" are updated directly to their target value.
        Other species are updated step by step, only at most +/-1 each update.
        """
        if self.localrule != []:
            logicalrule = localrule
        else:
            logicalrule=self.speciestype.rule
        for value in range(len(logicalrule)):
            if eval(logicalrule[value]):
                if self.speciestype.name[0] == "+": # this is just an expedient to have some kind of priority on the EGFR integration function...
#TODO: keep or remove this "+" priority, now (2013.10.19) that better priorities are in place?
                    transition = value - self.value
                else:
                    if value > self.value:
                        transition = 1
                    elif value < self.value:
                        transition = -1
                    else:
                        transition=0
        self.value += transition

class Cell():
    """ Hexagonal cells (x,y)
          /\  /\  /\  /\
         /  \/  \/  \/  \
         |0,0|1,0|2,0|3,0|
         \  /\  /\  /\  /\
          \/  \/  \/  \/  \
           |0,1|1,1|2,1|3,1|
          /\  /\  /\  /\
         /  \/  \/  \/  \
         |0,2|1,2|2,2|3,2|
         \  /\  /\  /\  /\
          \/  \/  \/  \/  \    """
    
    def __init__(self, parentgrid, x,y, index=None, listspecies=None, listneighbours=None, dictproxies={}):
        self.parentgrid=parentgrid
        self.index=index
        self.x=x
        self.y=y
        self.SONE = x + (-y + y%2)/2 #SONE (axis from SW to NE)
        self.NOSE = self.SONE+self.y    #NOSE (axis from NW to SE)
        self.pic=None
        self.dictproxies = {}
        if listneighbours:
            self.listneighbours = listneighbours
        else:
            self.listneighbours = []
            
        for name, function in dictproxies.items():
            self.dictproxies[name]={"value":0, "function":function}
        if listspecies:
            for species in listspecies:
                self.listspecies.append(Species(species, self))
            self.listspecies = sorted(self.listspecies, key=lambda x: x.name.lower(), reverse=True)
        else:
            self.listspecies=[]

    def about(self):
        print self.parentgrid
        print self.x
        print self.y
        print self.SONE
        print self.NOSE
        print self.pic
        print self.listspecies
    
    def addspecies(self, speciestype, value=0, localrule=[]):
        """Adds a species to the cell.
        """
        self.listspecies.append(Species(speciestype, self, value=value, localrule=localrule))
        self.listspecies = sorted(self.listspecies, key=lambda x: x.speciestype.name.lower(), reverse=True)




    def copy(self):
        """returns a copy of the cell.
        Picture (i.e., the hexagon that represent the cell on the canvas) is
        kept the same.
        """
        dp = {}
        for name, pr in self.dictproxies.items():
            dp[name] = pr["function"]
        #~ if self.x == 3 and self.y ==3:
            #~ print "copycell"
        c = Cell(self.parentgrid, self.x, self.y, listneighbours= self.listneighbours, dictproxies=dp)
        for species in self.listspecies:
            s = species.copy()
            c.addspecies(s.speciestype, s.value, s.localrule)
#            c.listspecies.append(species.copy())
        c.pic = self.pic
        #print c.getspecies("Floor").name
        return c

    def distanceTo(self, destinationcell):
        """returns the (straight line) distance from the one cell to the destinationcells, expressed in number of cells.
        """
        #------------------------------------ xo,yo = origincell.x, origincell.y
        #----------------------------------------------- SONEo = origincell.SONE
        #------------------------------------------------------ NOSEo = SONEo+yo
        #-------------------------- xd,yd = destinationcell.x, destinationcell.y
        #------------------------------------------ SONEd = destinationcell.SONE
        #------------------------------------------------------ NOSEd = SONEd+yd
        SONE, y, NOSE = destinationcell.SONE-self.SONE, destinationcell.y-self.y, destinationcell.NOSE-self.NOSE
        if (SONE>0 and y>=0 and NOSE>0) or (SONE<0 and y<=0 and NOSE<0):
            dist=abs(SONE) + abs(y)
        elif (SONE>0 and y<0 and NOSE>=0) or (SONE<0 and y>0 and NOSE<=0):
            dist=abs(NOSE) + abs(y)
        else:
            dist=abs(NOSE) + abs(SONE)
        return dist

    def getspecies(self, species):
        """returns a species from its name
        """
        for sp in self.listspecies:
            if sp.speciestype.name == species:
                return sp

    def haswith(self, species, distance=(1,1), value=1):
        """How many neighbours have the given state?"""
        count = 0
        for (x,y) in self.neighbours(d=distance, xmax=self.parentgrid.width, ymax=self.parentgrid.height):
            neighbour=self.parentgrid.fcgrid[y][x]
            if neighbour.getspecies(species).value == value:
                count +=1
        return count

    def neighbours(self, d=(1,1), xmax=0, ymax=0):
        """returns the cell's neighbours' coordinates on a hexagonal, finished grid
          /\  /\  /\  /\
         /  \/  \/  \/  \
         |0,0|1,0|2,0|3,0|
         \  /\  /\  /\  /\
          \/  \/  \/  \/  \
           |0,1|1,1|2,1|3,1|
          /\  /\  /\  /\  /
         /  \/  \/  \/  \/
        """
        x,y = self.x, self.y
        xmax= self.parentgrid.width
        ymax=self.parentgrid.height
        list_neighbours = []
        dmin,dmax = d
        diff = dmax +1 - len(self.listneighbours)
        #Note: self.listneighbours = [[self coord],[dist=1 neighbours], [dist=2 neighbours], ...]
        # list_neighbours = [dist = 0 -> n neighbours]

        for i in xrange(diff):
            self.listneighbours+= [[]]
            
        if dmin == 0:
            list_neighbours.append((x,y))
            if self.listneighbours[0] == []:
                self.listneighbours[0].append((x,y))
            dmin = 1 #this avoids including d=0 in the next loop

        for dist in xrange(dmin,dmax+1):
            d=dist
            if self.listneighbours[d] == []: # if neighbours have not yet been computed for distance d...
                for j in range(-d,d+1):
                    Y,X = y+j, x-(2*d-abs(j))/2 -((y+j)%2)*(j)%2
                    if (Y <0) or (Y >= ymax):
                        Y = Y % (ymax + ymax%2)
                    if X >=0 and Y >= 0 and X < xmax and Y < ymax:
                        list_neighbours.append((X,Y))
                        self.listneighbours[dist].append((X,Y))
                    Y,X = y+j, x+(2*d-abs(j))/2 +((y+j+1)%2)*(j)%2
                    if (Y <0) or (Y >= ymax):
                        Y = Y % (ymax + ymax%2)
                    if X >=0 and Y >= 0 and X < xmax and Y < ymax:
                        list_neighbours.append((X,Y))
                        self.listneighbours[dist].append((X,Y))
                for i in range(-d/2+1,d/2):
                    Y,X = y-d, x+i+(y%2)*(d%2)
                    if (Y <0) or (Y >= ymax):
                        Y = Y % (ymax + ymax%2)
                    if X >=0 and Y >= 0 and X < xmax and Y < ymax:
                        list_neighbours.append((X,Y))
                        self.listneighbours[dist].append((X,Y))
                    Y,X = y+d, x+i+(y%2)*(d%2)
                    if (Y <0) or (Y >= ymax):
                        Y = Y % (ymax + ymax%2)
                    if X >=0 and Y >= 0 and X < xmax and Y < ymax:
                        list_neighbours.append((X,Y))
                        self.listneighbours[dist].append((X,Y))
            else:
                list_neighbours+=self.listneighbours[dist]
        return list_neighbours



    #~ def updateproxies(self):
        #~ for proxy in self.dictproxies.values():
            #~ proxy["value"] = eval(proxy["function"])

    def update(self, priority=1):
        """Updates synchronously the values of the species contained in the cell.
        Copies each species that have the given priority and updates their values, one by one, based on the values of other species (in the cell and in the neighbours).
        Then, the updated values from the copies are copied back to the original species.
        Returns True if all updated values are identical to the original ones, i.e. if the state of the cell is stable.

        """

        stable = True
        update_list = []
        noupdate_list = []
        updated_list = []
        for species in self.listspecies: #listspecies is sorted alphabetically, species with name starting with a "+" come first — then 012..., ABC..., abc... #TODO: check if I still need alphabetic sorting (probably, for display, but maybe not here...)
            if species.speciestype.priority == priority:
                sp = species.copy()
                sp.update()
                update_list.append(sp)
                noupdate_list.append(species)
        for i in xrange(len(update_list)):
            usp = update_list[i]
            nusp = noupdate_list[i]
            if usp.value != nusp.value:
                stable = False
                nusp.value = usp.value
                updated_list.append(usp.speciestype.name)
        return stable, updated_list

        
class Model():
    
    def __init__(self, canvas, height, width, varparamSV, vareditSV, stateSV, ds={}, dictproxies={}, stateDict={}):
        
        self.dictproxies = dictproxies #"proxies" here are intended to be functions of other variables, whose value is computed "instantaneously" before each update. In particular, to handle "quantitative" integration of intercellular signals.
        self.dictspecies = ds
        self.stateDict= stateDict
        self.varparamSV =  varparamSV #holds the name of the variable selected for edition of its level
        self.vareditSV = vareditSV #holds the name of the variable selected for edition of its parameters (name, maxvalue, color and function)
        self.stateSV = stateSV #holds the name of the state selected for edition of its level

        self.height = height
        self.width = width
        self.canvas = canvas
        self.canvas.config(width=self.width*14+8, height=self.height*13+6, scrollregion=(0,0,width*14+8,height*13+6))
        if self.dictspecies != {}:
            s=sorted(self.dictspecies.keys(), key = lambda x:x.lower())[0]
            self.varparamSV.set(s)
            self.vareditSV.set(s)
        else:
            s = ""
            self.varparamSV.set(s)
            self.vareditSV.set(s)
        
        
        self.fcgrid = []
        for j in xrange(self.height):
            if j %2 ==1:
                tab = 7
            else:
                tab = 0
            self.fcgrid.append([])
            for i in xrange(self.width):
                name = str(j*self.height+i)
                self.fcgrid[j].append(Cell(self,i,j,index=name)) #self.fcgrid[j].append(Cell(self,i,j,index=name, dictproxies=self.dictproxies))
                self.fcgrid[j][i].pic = self.drawcell((tab+ i*14,j *13),"white",name)  #Keep or not? Maybe a property of the GUI, not the model...
                for sp in self.dictspecies.keys():
                    self.fcgrid[j][i].addspecies(self.dictspecies[sp], value=0, localrule=[])

        self.focus = []
        self.setfocus(None)
        
    def about(self):
        """Returns the model's description, including list of species and their logical rules, and list of states.
       State: lists of the cells where each variable takes its non-zerovalues.
        """
        model = etree.Element("model", width=str(self.width), height=str(self.height))
        for name, function in self.dictproxies.items():
            proxies = etree.SubElement(model, "proxies", name=name)
            proxies.text=str(function)
            
        for sp in self.dictspecies.values():
            globalspecies = etree.SubElement(model, "globalspecies", name=sp.name, max=str(sp.maxlevel), priority = str(sp.priority), color = sp.color)
            for r in sp.rule:
                rule= etree.SubElement(globalspecies, "rule")
                rule.text=r
        for s in self.stateDict.keys():
            state = etree.SubElement(model, "state", statename=s)
            for sp in self.stateDict[s].keys():
                species = etree.SubElement(state, "species",  speciesname=sp)
                species.text=str(self.stateDict[s][sp])

        indent(model) # emulates the pretyprint function
        text=etree.tostring(model)
        return (text)

    def deletespecies(self, del_sp):
        """deletes the selected species. Called by the "delete" button in the species notebook pannel.
        TODO: what happens with the new initial states when a species is deleted?"""
        del self.dictspecies[del_sp]
        if self.dictspecies != {}: #this "if" part is already present in __init__ => make a function?
            s=sorted(self.dictspecies.keys(), key = lambda x:x.lower())[0]
            self.varparamSV.set(s)
            self.vareditSV.set(s)   
        for i in xrange(self.width):
            for j in xrange(self.height):
                species = self.fcgrid[j][i].getspecies(del_sp)
                self.fcgrid[j][i].listspecies.remove(species)
        for state in self.stateDict.keys():
            if del_sp in self.stateDict[state].keys():
                del self.stateDict[state][del_sp]

    def deletestate(self,  state):
        """deletes the selected state"""
        del self.stateDict[state]
        
    def drawcell(self, topleft, color, tag):
        """draws an hexagonal cell on the canvas, from the topleft position,
        filled with the specified color.
        I don't think I'm really using the "tag" field, but at one point it
        just seemed like it could be useful to identify the cells.
        """
        #TODO: add scale
        x,y = topleft
        return self.canvas.create_polygon(x+7,y,x+14,y+5,x+14,y+13,
                                   x+7,y+18,x,y+13,x,y+5, outline="black", fill=color, tags=tag)

    def editspecies(self, species, newname, maxlevel, color, priority):
        """Creates a new species, or modifies an existing species. Affects every cells.
        When a new species is created, the initial state is not modified (default value=0)
        TODO: Add a warning that, when species name is modified, logical rules may get invalid. (Or even better, modify logical rules according to the new name...)
        """       
        maxlevel = int(maxlevel)
        priority = int(priority)
        color = color.upper()
        if species in self.dictspecies.keys():
            if species != newname:
                self.dictspecies[newname] = self.dictspecies[species]
                del self.dictspecies[species]
                self.dictspecies[newname].name= newname
                self.vareditSV.set(newname)
            
            if maxlevel != self.dictspecies[species].maxlevel:
                if maxlevel < self.dictspecies[newname].maxlevel:
                    self.dictspecies[species].rule = self.dictspecies[species].rule[:maxlevel + 1]
                    for i in xrange(self.width):
                        for j in xrange(self.height):
                            sp = self.fcgrid[j][i].getspecies(species)
                            if sp.localrule != []:
                                sp.localrule = self.dictspecies[newname].localrule[:maxlevel + 1]
                else:
                    for i in xrange(self.dictspecies[newname].maxlevel + 1, maxlevel +1):
                        rule = "self.parentcell.getspecies('" + newname + "').value==" + str(i)
                        self.dictspecies[species].rule.append(rule)
                    for i in xrange(self.width):
                        for j in xrange(self.height):
                            sp = self.fcgrid[j][i].getspecies(species)
                            if sp.localrule != []:
                                for i in xrange(self.dictspecies[newname].maxlevel + 1, maxlevel +1):
                                    rule = "self.parentcell.getspecies('" + newname + "').value==" + str(i)
                                    sp.localrule.append(rule)
                self.dictspecies[species].maxlevel = maxlevel
            if color != self.dictspecies[species].color:
                self.dictspecies[species].color=color
            if priority != self.dictspecies[species].priority:
                self.dictspecies[species].priority=priority
        else:
            defaultrule=[]
            for i in xrange(maxlevel+1):
                rule = "self.parentcell.getspecies('" + newname + "').value==" + str(i)
                defaultrule.append(rule)
            self.dictspecies[newname]= GlobalSpecies(newname, color=color, maxlevel=maxlevel, rule=defaultrule)
            for i in xrange(self.width):
                for j in xrange(self.height):
                    self.fcgrid[j][i].addspecies(self.dictspecies[newname])
        
            self.varparamSV.set(newname)
            self.vareditSV.set(newname)

            
            
    def loadstate(self):
        """Loads the selected state, i.e. changes the value of all variables in all cells. to those defined in the loaded state.
        State variable= list of variables whose value is not zero, and for each positive value the set of cells where the variable takes this value"""
        #state={'Roof': [[(7, 10), (8, 10), (6, 11), (7, 11), (6, 12), (7, 12), (5, 13), (6, 13), (7, 13), (4, 14), (5, 14), (6, 14), (7, 14), (8, 14), (9, 14), (10, 14), (6, 15), (7, 15), (6, 16), (7, 16), (7, 17)]], 'Dpp': [[(13, 8), (14, 8), (15, 8), (12, 9), (13, 9), (14, 9), (15, 9)], [(13, 10), (14, 10), (15, 10), (16, 10), (13, 11), (14, 11), (15, 11)]]}
        state = self.stateDict[self.stateSV.get()]
        for j in xrange(len(self.fcgrid)):
            for i in xrange(len(self.fcgrid[j])):
                for sp in self.dictspecies.keys():
                    self.fcgrid[j][i].getspecies(sp).value=0
                    if sp in state.keys():
                        for v in xrange(0, len(state[sp])):
                            if (i, j) in state[sp][v]:
                                self.fcgrid[j][i].getspecies(sp).value=v+1

    def savestate(self, statename):
            state={}
            for j in xrange(len(self.fcgrid)): #TODO: switch to width, height?)
                for i in xrange(len(self.fcgrid[j])): 
                    c=self.fcgrid[j][i] #for each cell in the grid...
                    for sp in c.listspecies: 
                        if sp.value !=0: # for each non-zero value, store the cell's coordinates in a list, with the corresponding species name as the key of a dictionnary
                            if sp.speciestype.name not in state:
                                state[sp.speciestype.name]=[]
                                for v in xrange(0, sp.speciestype.maxlevel):
                                    state[sp.speciestype.name].append([])
                            state[sp.speciestype.name][sp.value-1].append((i, j))
            self.stateDict[statename]=state


    def setfocus(self,cell):
        """Sets the focus on one cell; if no cell specified, selects all.
        """
        
        if cell == "All":
            for i in xrange(self.width):
                for j in xrange(self.height):
                    self.canvas.itemconfigure(self.fcgrid[j][i].pic, width=3) #sets a large border for the cells that gain focus
                    self.focus.append((i,j))
        elif cell == None:
            for i in xrange(self.width):
                for j in xrange(self.height):
                    self.canvas.itemconfigure(self.fcgrid[j][i].pic, width=1) #resets a thin border for the cells that gain focus
                    self.focus.append((i,j))
        else:
            x,y= cell
            if (x,y) not in self.focus:
                self.canvas.itemconfigure(self.fcgrid[y][x].pic, width=3) #sets a large border for the cells that gain focus
                self.focus.append((x,y))

    def setvalue(self, value):
        """Called by the "set" button in the parameter frame.
        Sets the value of the selected variable, in the selected cells, to the
        value specified in the "newvalue" Entry field.
        """
        for (x,y) in self.focus:
            self.fcgrid[y][x].getspecies(self.varparamSV.get()).value = int(value)
        
                
    def update(self):
        """Updates the grid.
        First updates "priority" variables (i.e., +EGFR in the mechanistic
        model): those are updated within the fcgrid itself.
        Then, creates an updated grid and replaces each cell in fcgrid with its
        updated copy.
        Returns "True" if the updated state is identical to the original one
        (i.e., if the pattern is stable).
        """
        stable=True
        updated_vars = []
        pmax=1
        for speciestype in self.dictspecies.values():
            p = speciestype.priority
            if p > pmax:
                pmax = p
        for p in xrange(1,pmax+1):
            nextgrid = []
            for j in range(self.height):
                nextgrid.append([])
                for i in range(self.width):
                    nextcell=self.fcgrid[j][i].copy()
                    (s, u) = nextcell.update(priority=p)
                    if not s:
                        stable = False
                        for v in u:
                            if v not in updated_vars:
                                updated_vars.append(v)
                    nextgrid[j].append(nextcell)

            if not stable:
                for j in range(self.height):
                    for i in range(self.width):
                        self.fcgrid[j][i] = nextgrid[j][i]
                break

        return stable, updated_vars       
        
class GUI():

    def __init__(self, root, directory):
        self.directory=directory
        self.mainwindow = root
        self.mainwindow.title("Follicular epithelium automaton")
        self.topframe = Frame(self.mainwindow)
        self.topframe.pack(fill=BOTH, expand=1)
        self.colorselection = []

        #####################################################################
        ## Main Part 1: the CONTROLS, simulating the model
        #####################################################################
        self.simulationframe = Frame(self.topframe, bd=2, height=60, relief=RAISED)
        self.simulationframe.grid(column=0,row=0, columnspan=2,  sticky=E+W)
        self.simulationframe.grid_propagate(1)
        Label(self.simulationframe,text="SIMULATION CONTROLS").grid(column=0,row=0, columnspan=3)
         
        Button(self.simulationframe,text="Update Once", command=self.update).grid(column=0,row=1)
        Button(self.simulationframe,text="Run x10", command=self.repeatupdate).grid(column=1,row=1)
        self.message_label = Label(self.simulationframe,text="Create or open a model to begin (\"File\" menu)")
        self.message_label.grid(column=2,row=1)

        
        #####################################################################
        ## Main Part 2: the CANVAS, on which the FE cells will be displayed.
        #####################################################################
        self.topframe.columnconfigure(0, weight=1)
        self.topframe.rowconfigure(1, weight=1)
        self.canvasframe = Frame(self.topframe,bd=2,relief=RAISED)
        self.canvasframe.grid(column=0,row=1,rowspan=3, sticky=N+S+W+E)
        self.canvasframe.columnconfigure(0, weight=1)
        self.canvasframe.rowconfigure(1, weight=1)
        self.canvasframe.grid_propagate(0)
        
        
        self.canvasyScroll = Scrollbar (self.canvasframe, orient=VERTICAL )
        self.canvasyScroll.grid (row=1, column=1, sticky=N+S )
        self.canvasxScroll = Scrollbar (self.canvasframe, orient=HORIZONTAL )
        self.canvasxScroll.grid (row=2, column=0, sticky=E+W )
        
        self.canvas = Canvas(self.canvasframe, xscrollcommand=self.canvasxScroll.set, yscrollcommand=self.canvasyScroll.set)
        self.canvas.grid(column=0, row=1)
        self.canvas.bind("<Button-1>", self.callback_Button1)
        self.canvas.bind("<B1-Motion>", self.callback_B1motion)
        
        #scrollregion is reconfigured when model is open to adjust to canvas size.


        self.canvasxScroll["command"] = self.canvas.xview
        self.canvasyScroll["command"] = self.canvas.yview


        #####################################################################
        ## Main Part 3a: the SPECIES, displaying the values of selection
        #####################################################################
        rightcolumnwidth=160
        self.topframe.columnconfigure(1, weight=0) #somehow makes the right column really stick to the right.
        self.displayframe = Frame(self.topframe,bd=2,relief=RAISED,width=rightcolumnwidth)
        self.displayframe.grid(column=1,row=1, rowspan=2, sticky=E+N+S)
        self.displayframe.grid_propagate(1)
        Label(self.displayframe,text="Select Display").grid(column=0,row=0)
        self.displaylistbox = Listbox(self.displayframe, selectmode=MULTIPLE,activestyle='dotbox')
        self.displaylistbox.grid(column=0,row=1, sticky=N+S)
        self.displayframe.rowconfigure(1, weight=1)
        Button(self.displayframe,text="Show", command=self.setColorselection).grid(column=0,row=2)
        Label(self.displayframe,text="Showing:").grid(column=0,row=3)
        self.displaylabel = Label(self.displayframe,text='None')
        self.displaylabel.grid(column=0,row=4)

 
 
        #####################################################################
        ## Main Part 3b: EDITING the LOCAL PARAMETERS of the SELECTION
        #####################################################################
        self.paramframe = Frame(self.topframe,bd=2,relief=RAISED,width=rightcolumnwidth)
        self.paramframe.grid(column=1,row=3,  sticky=E)
        self.paramframe.grid_propagate(1) 
        
        self.varparamSV = StringVar(self.paramframe) #holds the name of the variable selected for edition of its level




        Label(self.paramframe,text="Edit the LEVELS of the\nSELECTION here").grid(column=0,row=0)
        self.varparamButton = OptionMenu(self.paramframe,  self.varparamSV,  ())
        self.varparamButton.grid(column=0,  row=1)
        
        self.newvalue = Entry(self.paramframe)
        self.newvalue.grid(column=0,row=2)
        
        self.newvalue.bind("<KeyRelease>", self.checknewvalue)
        Button(self.paramframe,text="Set", command=lambda :(self.setspeciesvalue(), self.display())).grid(column=0,row=3)




        #####################################################################
        ## Main Part 4: EDITING VARIABLES
        #####################################################################
        self.speciesframe = Frame(self.topframe,bd=2,relief=RAISED)
        self.speciesframe.grid(column=0,row=4,rowspan=1, columnspan=2, sticky=S+E+W)
        self.speciesframe.grid_propagate(1)
        self.speciesframe.grid_columnconfigure(1, weight=1)

        #####################################################################
        ## Main Part 4a: MANAGING VARIABLES
        #####################################################################
        self.idframe = Frame(self.speciesframe,bd=2, relief=RAISED,  height=150)
        self.idframe.grid(column=0,row=0,   sticky=N+E+S+W)
        self.vareditSV = StringVar(self.idframe) #holds the name of the variable selected for edition of its parameters (name, maxvalue, color and function)
        buttonFrame = Frame(self.idframe,bd=2, relief=RAISED)
        buttonFrame.grid(row=0,  columnspan=2)

        self.vareditButton = OptionMenu(buttonFrame,  self.vareditSV,  ())
        self.vareditButton.config(width=5)
        self.vareditButton.grid(column=0,  row=0)
        Button(buttonFrame, text="delete", command=self.deletespecies).grid(column=1,row=0)
        Button(buttonFrame, text="create new", command=lambda : (self.createspecies(None))).grid(column=3,row=0)     
        
        self.validspecies=0
        Label(self.idframe, text="Name").grid(column=0, row=1)
        self.sp_nameEntry = Entry(self.idframe, width=15)
        self.sp_nameEntry.bind("<KeyRelease>", self.checkspeciesname)
        self.sp_nameEntry.bind("<FocusOut>",  lambda event :(self.editspecies(self.vareditSV.get(), self.sp_nameEntry.get(),  self.sp_maxEntry.get(), self.sp_colorEntry.get(), self.sp_priorityEntry.get())))
        self.sp_nameEntry.grid(column=1,row=1)
        Label(self.idframe, text="max level").grid(column=0, row=2)
        self.sp_maxEntry = Entry(self.idframe, width=15)
        self.sp_maxEntry.bind("<KeyRelease>", self.checkmaxlevel)
        self.sp_maxEntry.bind("<FocusOut>",  lambda event :(self.editspecies(self.vareditSV.get(), self.sp_nameEntry.get(),  self.sp_maxEntry.get(), self.sp_colorEntry.get(), self.sp_priorityEntry.get())))
        self.sp_maxEntry.grid(column=1,row=2)
        Label(self.idframe, text="color").grid(column=0, row=3)
        self.sp_colorEntry = Entry(self.idframe, width=15)
        self.sp_colorEntry.bind("<KeyRelease>", self.checkcolor)
        self.sp_colorEntry.bind("<FocusOut>",  lambda event :(self.editspecies(self.vareditSV.get(), self.sp_nameEntry.get(),  self.sp_maxEntry.get(), self.sp_colorEntry.get(), self.sp_priorityEntry.get())))
        self.sp_colorEntry.grid(column=1,row=3)
        Label(self.idframe, text="priority").grid(column=0, row=4)
        self.sp_priorityEntry = Entry(self.idframe, width=15)
        self.sp_priorityEntry.bind("<KeyRelease>", self.checkpriority)
        self.sp_priorityEntry.bind("<FocusOut>",  lambda event :(self.editspecies(self.vareditSV.get(), self.sp_nameEntry.get(),  self.sp_maxEntry.get(), self.sp_colorEntry.get(), self.sp_priorityEntry.get())))
        self.sp_priorityEntry.grid(column=1,row=4)

        
        #####################################################################
        ## Main Part 4b: EDITING LOGICAL FUNCTIONS
        #####################################################################
        #Displays global attributes of species (name, color, maxlevel and rule)
        self.functionsframe = Frame(self.speciesframe,bd=2, relief=RAISED,  height=150,  width=300)
        self.functionsframe.grid(column=1,row=0, sticky=E+W)
        self.functionsframe.grid_propagate(1)
        Label(self.functionsframe,text="Logical functions").grid(column=0,row=0)
        
        self.yScroll = Scrollbar ( self.functionsframe, orient=VERTICAL )
        self.yScroll.grid ( row=1, column=1, sticky=N+S )
        self.xScroll = Scrollbar ( self.functionsframe, orient=HORIZONTAL )
        self.xScroll.grid ( row=2, column=0, sticky=E+W )
        self.functionlistbox = Listbox(self.functionsframe,activestyle='dotbox', xscrollcommand=self.xScroll.set, yscrollcommand=self.yScroll.set , height=4, width=80)
        self.functionlistbox.grid(column=0,row=1, sticky=E+W)
        
        
        
        self.xScroll["command"] = self.functionlistbox.xview
        self.yScroll["command"] = self.functionlistbox.yview



        Button(self.functionsframe, text="edit rule", command=self.editrule).grid(column=0,row=3)
                
        

        #####################################################################
        ## Main Part 4c: EDITING the PROXY functions
        #####################################################################
        #Not in use anymore... for now ?
        self.proxeditframe = Frame(self.topframe,bd=2,relief=RAISED)
        self.proxeditframe.grid(column=0,row=5,rowspan=1, columnspan=2, sticky=E+W)
        self.proxeditframe.grid_propagate(0)
        self.proxeditlabel = Label(self.proxeditframe,text="Edit the PROXIES here").grid(column=0,row=0)
        self.proxies_yScroll = Scrollbar (self.proxeditframe, orient=VERTICAL )
        self.proxies_yScroll.grid ( row=1, column=1, sticky=N+S )
        self.proxies_xScroll = Scrollbar (self.proxeditframe, orient=HORIZONTAL )
        self.proxies_xScroll.grid ( row=2, column=0, sticky=E+W )
        


        self.proxylistbox = Listbox(self.proxeditframe,activestyle='dotbox', xscrollcommand=self.xScroll.set, yscrollcommand=self.yScroll.set , height=4, width=80)
        self.proxylistbox.grid(column=0,row=1)    
        self.proxies_xScroll["command"] = self.proxylistbox.xview
        self.proxies_yScroll["command"] = self.proxylistbox.yview
        
        Button(self.proxeditframe, text="edit", command=self.editproxy).grid(column=0,row=3)
        
        
        ############### Menu Bar ###################
        menubar = Menu(self.mainwindow)
        # create file menu, and add it to the menu bar
        self.filemenu = Menu(menubar, tearoff=0)
        self.filemenu.add_command(label="New", command=self.createmodel)
        self.filemenu.add_command(label="Open", command=self.openmodel)
        self.filemenu.add_command(label="Save", command=self.savemodel, state="disabled")
        self.filemenu.add_separator()
        self.filemenu.add_command(label="Exit", command=self.mainwindow.quit)
        menubar.add_cascade(label="File", menu=self.filemenu)
        # create edit menus
        self.editmenu = Menu(menubar, tearoff=0)
        self.editmenu.add_command(label="Select All Cells", command=lambda:(self.model.setfocus("All"), self.updatedisplaylistbox()), state="disabled")
        self.editmenu.add_command(label="Unselect", command=lambda:(self.model.setfocus(None), self.updatedisplaylistbox()), state="disabled")

        menubar.add_cascade(label="Edit", menu=self.editmenu)
        # create a menu for state management
        stateMenu = Menu(menubar,  tearoff=0)
        self.loadstateMenu = Menu(stateMenu,  tearoff=0)
        stateMenu.add_cascade(label="Load", menu=self.loadstateMenu)
        self.savestateMenu = Menu(stateMenu,  tearoff=0)
        stateMenu.add_cascade(label="Save", menu=self.savestateMenu)
        self.delstateMenu = Menu(stateMenu,  tearoff=0)
        stateMenu.add_cascade(label="Delete", menu=self.delstateMenu)
        menubar.add_cascade(label="States", menu=stateMenu)
        
        self.stateSV = StringVar(self.simulationframe)
        #
        self.mainwindow.config(menu=menubar)




    def display_rule(self, args=None):
        """in the parameters panel, displays the rule corresponding to the
        selected value of the selected species in the "Entry" textbox where
        it can be modified
        """
        x,y = self.model.focus[0][0],self.model.focus[0][1]
        rule = self.fcgrid[y][x].getspecies(self.varparamSV.get()).logicalrule[int(args)]
        self.newparam.delete(0, END)
        self.newparam.insert(0, rule)


    def about(self):
        print self.name


    def callback_B1motion(self, event):
        """what happens when the mouse is moved after clicking on the grid and
        letting left button pressed.
        Basically, adds cells that are moved over to the "focus" list.
        """
        x,y=int(self.canvas.canvasx(event.x)),int(self.canvas.canvasy(event.y))
        X = -1
        Y = (y-1) / 13
        if y in range(Y*13+5, Y*13+14):
            if Y%2==0:
                X = x/14
            elif event.x >=7:
                X = (x-7)/14
            else:
                X = 0
        if X >= 0:
            self.model.setfocus((X,Y))
        self.updatedisplaylistbox()

    def callback_Button1(self, event):
        """Defines what happens when one clicks on the grid.
        For the sake of simplicity, the cells are approximated to their central
        part, so nothing happens if one clicks in the top or bottom angles
        """
        x,y=int(self.canvas.canvasx(event.x)),int(self.canvas.canvasy(event.y))
        X = -1
        Y = (y-1) / 13
        if y in range(Y*13+5, Y*13+14):
            if Y%2==0:
                X = x/14
            elif event.x >=7:
                X = (x-7)/14
            else:
                X = 0
        
        if X >= 0:
            for (i,j) in self.model.focus:
            #self.focus is a list of cell coordinates)
                self.canvas.itemconfigure(self.model.fcgrid[j][i].pic, width=1)
                #resets a thin border for the cells that are losing the focus
            self.model.focus = []
            self.model.setfocus((X,Y))
        self.updatedisplaylistbox()


    def checkspeciesname(self,  event=None):
        """makes sure that the new name (when creating of modifying a species) doesn't already exist"""
        species= self.vareditSV.get()
        newname = self.sp_nameEntry.get()
        if newname == "" or (newname != species and newname in self.model.dictspecies.keys()):
            self.sp_nameEntry.config(bg="red")
            return 0
        elif newname != species:
            self.sp_nameEntry.config(bg="yellow")
            return 1
        else:
            self.sp_nameEntry.config(bg="white")
            return 1

    def checkcolor(self, event=None):
        """makes sure that the new color (when creating of modifying a species) is in the correct format. TODO: make it work..."""
        species = self.vareditSV.get()
        color = self.sp_colorEntry.get().upper()
        if color == "":
            self.sp_colorEntry.config(bg="red")
            return 0
        elif len(color) == 7 and color[0] == "#":
            for i in xrange(6):
                if color[i + 1] not in ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"]:
                    self.sp_colorEntry.config(bg="red")
                    return 0
            if species in self.model.dictspecies.keys():
                if color == self.model.dictspecies[species].color:
                    self.sp_colorEntry.config(bg="white")
                else:
                    self.sp_colorEntry.config(bg="yellow")
            else:
                self.sp_colorEntry.config(bg="yellow")
            return 1
        else:
            self.sp_colorEntry.config(bg="red")
            return 0
    
    def checkmaxlevel(self,  event=None):
        """makes sure that the new maximum level (when creating of modifying a species) is a positive integer"""
        species= self.vareditSV.get()
        maxlevel = self.sp_maxEntry.get()
        if maxlevel == "":
            self.sp_maxEntry.config(bg="red")
            return 0
        else:
            try:
                maxlevel = int(maxlevel)
                if maxlevel <1:
                    self.sp_maxEntry.config(bg="red")
                    return 0
                else:
                    if self.vareditSV.get() != "" and maxlevel == self.model.dictspecies[self.vareditSV.get()].maxlevel:
                        self.sp_maxEntry.config(bg="white")
                    else:
                        self.sp_maxEntry.config(bg="yellow")
                return 1
            except:
                self.sp_maxEntry.config(bg="red")
                return 0

    def checknewvalue(self, event=None):
        try:
            value = int(self.newvalue.get())
            if value <= self.model.dictspecies[self.varparamSV.get()].maxlevel and value >=0:
                self.newvalue.config(bg="white")
                return(1)
            else:
                self.newvalue.config(bg="red")
                return(0)
        except:
            self.newvalue.config(bg="red")
            return(0)

    def checkpriority(self,  event=None):
        species = self.vareditSV.get()
        priority = self.sp_priorityEntry.get()
        if priority == "":
            self.sp_priorityEntry.config(bg="red")
            return 0
        else:
            try:
                priority = int(priority)
                if priority < 1:
                    self.sp_priorityEntry.config(bg="red")
                    return 0
                else:
                    if species in self.model.dictspecies.keys(): 
                        if priority == self.model.dictspecies[species].priority:
                            self.sp_priorityEntry.config(bg="white")
                        else:
                            self.sp_priorityEntry.config(bg="yellow")
                    else:
                        self.sp_priorityEntry.config(bg="yellow")
                    return 1
            except:
                self.sp_priorityEntry.config(bg="red")
                return 0

        

    def createmodel(self,parameters=None):
        if parameters:
            canvas, height, width, varparamSV, vareditSV, stateSV, stateDict, ds, dictproxies = parameters

            self.model = Model(canvas, height, width, varparamSV, vareditSV, stateSV, stateDict=stateDict, ds=ds, dictproxies=dictproxies)
            self.editmenu.entryconfig(0, state="normal")
            self.editmenu.entryconfig(1, state="normal")
            self.filemenu.entryconfig(2, state="normal")

            self.fillinputselectionmenu()
            self.colorselection=[]
            self.fillspeciespanel()
            self.fillStateMenu()
            self.display()

            name="new model"
            self.mainwindow.title("Follicular epithelium automaton"+": "+name)
            self.message("Model created")
        else:
            newmodelpannel = Toplevel()
            Label(newmodelpannel, text="height").grid(column=0, row=0)
            height = Entry(newmodelpannel, width=10)
            height.grid(column=1,row=0, sticky=N+S+E+W)
            
            Label(newmodelpannel, text="width").grid(column=0, row=1)
            width = Entry(newmodelpannel, width=10)
            width.grid(column=1,row=1, sticky=N+S+E+W)

            Button(newmodelpannel, text="Create", command=lambda : (self.canvas.delete(ALL), self.createmodel((self.canvas, int(height.get()), int(width.get()), self.varparamSV, self.vareditSV, self.stateSV, {}, {}, {})), newmodelpannel.destroy())).grid(column=0, row=3)

    def createspecies(self, sp=None):
        """empties the fields for species name, maxlevel and color so that, if modified, a new species can be created .
        """
        self.vareditSV.set("")
        self.sp_nameEntry.delete(0, END)
        self.sp_maxEntry.delete(0, END)
        self.sp_colorEntry.delete(0, END)
        self.sp_priorityEntry.delete(0, END)


    
    def editspecies(self, species, newname, maxlevel, color, priority):
        """Creates a new species, or modifies an existing species. Affects every cells.
        When a new species is created, the initial state is not modified (default value=0)
        TODO: Add a warning that, when species name is modified, logical rules may get invalid. (Or even better, modify logical rules according to the new name...)
        """       
        
        if self.checkspeciesname() and self.checkmaxlevel() and self.checkcolor() and self.checkpriority():
            # edit the species in the model object
            self.model.editspecies(species, newname, maxlevel, color, priority)
            # reset configuration to the defaults, non-modified values
            self.sp_nameEntry.config(bg="white")
            self.sp_maxEntry.config(bg="white")
            self.sp_colorEntry.config(bg="white")
            self.sp_priorityEntry.config(bg="white")
            # and updates the menus and displays
            self.fillinputselectionmenu()
            self.fill_globalspecies_rules_list()
            self.display()

    
    
    def deletespecies(self, del_sp=None):
        """deletes the selected species. Called by the "delete" button in the species notebook pannel.
        TODO: what happens with the new initial states when a species is deleted?"""
        if del_sp==None:
            del_sp=self.vareditSV.get()
        self.model.deletespecies(del_sp)
        if del_sp in self.colorselection:
            self.colorselection.remove(del_sp)
        self.fill_globalspecies_rules_list()
        self.fillinputselectionmenu()
        self.fillspeciespanel()
        self.display()


    def deletestate(self,  state):
        """deletes the selected state"""
        self.model.deletestate(state)
        self.message("State \"{}\" has been deleted".format(state))
        self.fillStateMenu()


        
    def display(self):
        """updates the canvas and selection panel."""
        self.updatedisplaylistbox()
        self.updatecolors()



    def editrule(self):
        """opens a panel to edit the selected rule.
        """
        def checkrule(species, index, testrule):
            OK = False
            testcell = self.model.fcgrid[0][0].copy()
            oldrule = self.model.dictspecies[species].rule[index]
            self.model.dictspecies[species].rule[index] = testrule
            try:
                OK = True
                if oldrule == testrule:
                    sp_rule.config(bg="white")
                else:
                    for sp in testcell.listspecies:
                        if sp.speciestype.name == species:
                            sp.update()
                            sp_rule.config(bg="yellow")         
            except:
                sp_rule.config(bg="red") 
                OK = False
            self.model.dictspecies[species].rule[index] = oldrule
            if OK:
                return 1
            else: 
                return 0
                
        def setrule():
            if checkrule(sp, index, sp_rule.get("0.0", END)[:-1]):
                self.model.dictspecies[sp].setrule(int(index), sp_rule.get("0.0", END)[:-1]) 
                self.fill_globalspecies_rules_list() 
                ruleeditpannel.destroy()
            
        index=int(self.functionlistbox.curselection()[0])+1
        sp = self.vareditSV.get()
        rule=self.model.dictspecies[sp].rule[int(index)]
        
        ruleeditpannel = Toplevel()
        
        Label(ruleeditpannel, text="Rule for %s level %s" %(sp, index)).grid(column=0, row=0)
        sp_rule = Text(ruleeditpannel, height=6, width=70)
        sp_rule.bind("<KeyRelease>", lambda event: checkrule(sp, index, sp_rule.get("0.0", END)[:-1]))
        sp_rule.grid(column=0,row=1, sticky=N+S+E+W)
        sp_rule.delete("0.0", END)
        sp_rule.insert("0.0", rule)
        
        Button(ruleeditpannel, text="Set", command=setrule).grid(column=0, row=3)
        
    def editproxy(self):
        """opens a panel to edit the selected proxy. Proxies were meant to handle more "quantitative" integration of signals from different cells. Not really in use anymore... for now.
        TODO: add possibility to rename the proxy
        """
        #TODO: add scrollbars.
        
        #name=self.globalproxies_Hlist.info_selection()[0]
        
        #self.proxyselection = self.dictproxies.keys()[int(self.proxylistbox.curselection()[0])]
        name = self.dictproxies.keys()[int(self.proxylistbox.curselection()[0])]


        function=self.dictproxies[name]
        
        proxyeditpannel = Toplevel()
        
        Label(proxyeditpannel, text="Proxy name").grid(column=0, row=0)
        nameEntry = Entry(proxyeditpannel)
        nameEntry.grid(column=0,row=1, sticky=N+S+E+W)
        nameEntry.delete("0", END)
        nameEntry.insert("0", name)
        functionText = Text(proxyeditpannel, height=6, width=70)
        functionText.grid(column=0,row=2, sticky=N+S+E+W)
        functionText.delete("0.0", END)
        functionText.insert("0.0", function)
        
        Button(proxyeditpannel, text="Set", command=lambda : (self.setproxy(name,functionText.get("0.0", END)[:-1]), proxyeditpannel.destroy(), self.display())).grid(column=0, row=3)        

    def fill_globalspecies_rules_list(self):
        """displays (within the "globalspecies_rule_display" HList in the species panel of the Notebook) the default logical rules for the selected variable
        """
        self.functionlistbox.delete(0,END)
        if self.vareditSV.get() != "":
            for value in xrange(1, len(self.model.dictspecies[self.vareditSV.get()].rule)):
                rule = self.model.dictspecies[self.vareditSV.get()].rule[value]
                self.functionlistbox.insert(END, "level " + str(value) +": " + rule)

    def fillinputselectionmenu(self):
        self.vareditButton["menu"].delete(0, END)
        self.varparamButton["menu"].delete(0, END)
        for sp in sorted(self.model.dictspecies.keys(), key=lambda x: x.lower()):
            self.vareditButton["menu"].add_radiobutton(label=sp, value=sp, variable=self.vareditSV,  command=self.fillspeciespanel) 
            self.varparamButton["menu"].add_radiobutton(label=sp, value=sp, variable=self.varparamSV, command=self.checknewvalue) 
        
    def fillStateMenu(self, newstate=None):
        
        self.loadstateMenu.delete(0, END)
        self.savestateMenu.delete(0, END)
        self.delstateMenu.delete(0, END)
        self.savestateMenu.add_radiobutton(label="Create new",  variable=self.stateSV, command=self.savestate) 
        self.savestateMenu.add_separator()

        for state in sorted(self.model.stateDict.keys(), key=lambda x: x.lower()):
            self.loadstateMenu.add_radiobutton(label=state, value=state, variable=self.stateSV, command=self.loadstate)
            self.savestateMenu.add_radiobutton(label=state, value=state, variable=self.stateSV,  command=lambda:(self.savestate(self.stateSV.get())))
            self.delstateMenu.add_radiobutton(label=state, value=state, variable=self.stateSV, command=lambda:(self.deletestate(self.stateSV.get())))
        self.stateSV.set(None) #So that the menu/radiobutton does not show which state has been loaded / saved last

            
    def fillspeciespanel(self,  edit=0):
        
        if edit:
            pass
        else:
            varname = self.vareditSV.get()
            self.sp_nameEntry.delete(0, END)
            self.sp_maxEntry.delete(0, END)
            self.sp_colorEntry.delete(0, END)
            self.sp_priorityEntry.delete(0, END)
            if varname != "":
                self.sp_nameEntry.insert(0, varname)
                self.sp_maxEntry.insert(0, self.model.dictspecies[varname].maxlevel)
                self.sp_colorEntry.insert(0, self.model.dictspecies[varname].color)
                self.sp_priorityEntry.insert(0, self.model.dictspecies[varname].priority)
            self.fill_globalspecies_rules_list()
        
        
    def loadstate(self):
        """Loads the selected state, i.e. changes the value of all variables in all cells. to those defined in the loaded state.
        State variable= list of variables whose value is not zero, and for each positive value the set of cells where the variable takes this value"""
        self.model.loadstate()
        self.message("State loaded: {}".format(self.stateSV.get()))
        self.stateSV.set(None) #So that the menu/radiobutton does not show which state has been loaded / saved last
        self.display()
                        
    def message(self, msg):
        self.message_label["text"] = msg
        
    def openmodel(self):
        """Opens a model from a file"""
        filename =  tkFileDialog.askopenfilename(initialdir=self.directory)
        try:
            f = open(filename, "r")
            tree = etree.parse(f)
            model=tree.getroot()
            
            self.canvas.delete(ALL)
            color="#ffffff"


            height = int(model.attrib["height"])
            width = int(model.attrib["width"])
            
            dictproxies = {}
            for pr in model.iterfind("proxies"):
                dictproxies[pr.attrib["name"]]=pr.text

            #Load the list of species
            dictspecies = {}
            for sp in model.iterfind("globalspecies"):
                n = sp.attrib["name"]
                c = sp.attrib["color"]
                m= int(sp.attrib["max"])
                if "priority" in sp.attrib.keys(): # for older models before priorities where introduced (2013.10.19)
                    p = int(sp.attrib["priority"])
                else:
                    p=1
                r=[]
                for rule in sp.iterfind("rule"):
                    r.append(rule.text)
                dictspecies[n] = GlobalSpecies(n, color=c, maxlevel=m, priority=p, rule=r)


            
            stateDict={}
            for s in model.iterfind("state"):
                statename= s.attrib["statename"]
                stateDict[s.attrib["statename"]]={}
                for sp in s.iterfind("species"):
                    stateDict[s.attrib["statename"]][sp.attrib["speciesname"]]=eval(sp.text)
            #TODO add "load initial state". Make sure "initialstate" can't be deleted.
            f.close()

            self.createmodel((self.canvas, height, width, self.varparamSV, self.vareditSV, self.stateSV, stateDict, dictspecies, dictproxies))
            
            #self.model = Model(self.canvas, height, width, self.varparamSV, self.vareditSV, self.stateSV, stateDict= stateDict, ds=dictspecies, dictproxies=dictproxies)
            
            name=filename.split("/")[-1]
            self.mainwindow.title("Follicular epithelium automaton"+": "+name)
            self.message("Opened model " + name)
        except:
            print "Failed to open."
            pass

    def repeatupdate(self, n=10):
        """repeats update n times or until it reaches a stable state
        """
        m = n
        s=False
        updated = []
        while not s and n:
            n -=1
            s, l = self.update()
            for v in l:
                if v not in updated:
                    updated.append(v)
        if n :
            self.message("Stable state reached after {} iteration(s). Updated: {}".format(m-n+1,updated))
        else:
            self.message("Reached no stable state. Updated: {}".format(updated))


    def savemodel(self):
        """Saves the model, including list of species and their logical rules, and list of states.
       State: lists of the cells where each variable takes its non-zerovalues.
        """
        text= self.model.about()
        filename = tkFileDialog.asksaveasfilename(defaultextension=".txt", initialdir=self.directory)
        try:
            f = open(filename, "w")
            f.write(text)
            f.close()
            name=filename.split("/")[-1]
            self.mainwindow.title("Follicular epithelium automaton"+": "+name)
            self.message("Model saved as \"{}\"".format(name))
        except:
            pass

    def savestate(self, statename=None):
        """Save the current state of the system, i.e. the value of all variables in all cells.
        State = dictionary of variables whose value is not zero, and for each positive value the set of cells where the variable takes this value"""
        if statename==None:
            statepannel = Toplevel()
            Label(statepannel, text="Name").grid(column=0, row=0)
            statenameEntry = Entry(statepannel, width=50)
            statenameEntry.grid(column=1,row=0)
            Button(statepannel, text="Save", command=lambda : (self.savestate(statenameEntry.get()), statepannel.destroy())).grid(column=0, row=3)
        else:
            self.model.savestate(statename)
            self.message("State saved as \"{}\"".format(statename)) 
            self.fillStateMenu(statename)
            self.stateSV.set(None) #So that the menu/radiobutton does not show which state has been loaded / saved last
           
        

            


    def setColorselection(self):
        """Called by the "show" button in self.displayframe. Set the list of species that will appear on the canvas"""
        cursel = self.displaylistbox.curselection()
        self.colorselection=[]
        specieslist=sorted(self.model.dictspecies.keys(), key=lambda x: x.lower(), reverse=False)
        for i in range(len(cursel)):
            self.colorselection.append(specieslist[int(cursel[i])])
        self.updatecolors()




    def setproxy(self,name,function):
        self.dictproxies[name]=function
        for j in xrange(self.height):
            for i in xrange(self.width):
                self.fcgrid[j][i].dictproxies[name]["function"]=function


    def setspeciesvalue(self):
        if self.checknewvalue():
            self.model.setvalue(self.newvalue.get())


    def update(self):
        """Updates the grid.
        First updates "priority" variables (i.e., +EGFR in the mechanistic
        model): those are updated within the fcgrid itself.
        Then, creates an updated grid and replaces each cell in fcgrid with its
        updated copy.
        Returns "True" if the updated state is identical to the original one
        (i.e., if the pattern is stable).
        """
        try:
            stable,v = self.model.update()
    #        msg = "Updated once; stability: " + str(stable)
    #        self.message(msg)
            self.message("Updated once: {}. Stable: {}".format(v,stable))
            self.display()
            return stable, v
        except:
            self.message("No model to update. Create or open a model to begin (\"File\" menu)")



    def updatecolors(self):
        """Called by the display function, to update the colors of the cells on the canvas, based on the values of the selected species.
        """
        for j in range(self.model.height):
            for i in range(self.model.width):
                colors =[]
                for species in self.colorselection:
                    colormix=[]
                    for value in xrange(self.model.fcgrid[j][i].getspecies(species).value):
                        colormix.append(self.model.dictspecies[species].color)
                    for value in xrange(self.model.dictspecies[species].maxlevel - self.model.fcgrid[j][i].getspecies(species).value):
                        colormix.append("#ffffff")
                    if colormix != []:
                        c = mixcolors(colormix)
                        if c != "#ffffff":
                            colors.append(c)
                if colors != []:
                    self.canvas.itemconfig(self.model.fcgrid[j][i].pic, fill=mixcolors(colors))
                else:
                    self.model.canvas.itemconfig(self.model.fcgrid[j][i].pic, fill="#ffffff")
        labeltext = ''
        if len(self.colorselection) == 0:
            labeltext = 'None'
        for i in range(len(self.colorselection)):
            addition = self.colorselection[i]
            if len(self.colorselection) != i+1: addition = addition + ', '
            if (i+1)%3 == 0 and i: addition = addition + '\n'
            labeltext = labeltext + addition
        self.displaylabel["text"] = labeltext

    def updatedisplaylistbox(self):
        """Updates the displaylistbox with the values of the variables in the cells that have focus. Called by the display function, and called every time the list of species is modified."""
        display={}
        #~ proxydisplay={}
        self.displaylistbox.delete(0,self.displaylistbox.size())
        #~ self.proxylistbox.delete(0,self.proxylistbox.size())
        
        #~ x,y = self.model.focus[0]
        for species in self.model.dictspecies.keys():
            display[species]=[self.model.dictspecies[species].maxlevel,0]
            #~ display[species]=[self.model.fcgrid[y][x].getspecies(species).value,0]
        #~ for proxy in self.dictproxies.keys():
            #~ proxydisplay[proxy]=[self.fcgrid[y][x].dictproxies[proxy]["value"],0]
        for x,y in self.model.focus:
            #self.model.fcgrid[y][x].updateproxies()
            for species in self.model.fcgrid[y][x].listspecies:
                if species.value < display[species.speciestype.name][0]:
                    display[species.speciestype.name][0] = species.value
                if species.value > display[species.speciestype.name][1]:
                    display[species.speciestype.name][1] = species.value
            #~ for proxy in self.model.dictproxies.keys():
                #~ value=self.fcgrid[y][x].dictproxies[proxy]["value"]
                #~ if value < proxydisplay[proxy][0]:
                    #~ proxydisplay[proxy][0] = value
                #~ if value > proxydisplay[proxy][1]:
                    #~ proxydisplay[proxy][1] = value
                #~ self.fcgrid[y][x].dictproxies[proxy]["value"]

        for species in sorted(display.keys(), key=lambda x: x.lower(), reverse=False):
            if display[species][0] == display[species][1]:
                self.displaylistbox.insert(END,species + ' = '+ str(display[species][0]))
            else:
                self.displaylistbox.insert(END,species + ' = '+ "[{0}-{1}]".format(display[species][0], display[species][1]))


def main():
    filename=sys.argv[0]
    directory=filename.strip('\'"/').rpartition("/")[0]
    root = directory.partition("/")[0]
    cur_dir = os.getcwd() + "/"
    if root and root in cur_dir:
        directory = cur_dir.partition(root)[0] + directory
    else:
        directory = cur_dir + directory
    root = Tk()
    GUI(root,directory)
    root.mainloop()
if __name__ == '__main__': main()
